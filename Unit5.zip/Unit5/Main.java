public class Main {
public static void main(String[] args){
    Point p1=new Point();
    Point p2=new Point(2,5);
    Point p3=new Point(2,5);
    System.out.println(p3.equals(p2));
    String s1=new String("ab");
    String s2=new String("ab");
    System.out.println(s1.equals(s2));
    //
    Circle c1=new Circle();
    Circle c2=new Circle(2,2,3);
    System.out.println(c1.getArea()+" "+c1.isInCircle(1,1));
    c1.translate(2,2);
    c1.tripleTheRadius();
    System.out.println(c1.getArea()+" "+c1.isInCircle(3,3));
}

}
