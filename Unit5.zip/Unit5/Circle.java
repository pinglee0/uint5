public class Circle {
    private int x;
    private int y;
    private double radius;
    public Circle(){
        x = 0;
        y = 0;
        radius=1;
    }
    public Circle(int xValue, int yValue,double rValue){
        x = xValue;
        y = yValue;
        radius=rValue;
    }
    public double getArea(){
        return Math.PI*Math.pow(radius,2);
    }
    public boolean isInCircle(int a, int b){
        return Math.pow(a-x,2)+Math.pow(b-y,2)<Math.pow(radius,2);
    }
    public void translate(int dx, int dy){
        x+=dx;
        y+=dy;
    }
    public void tripleTheRadius(){
        radius*=3;
    }

}
