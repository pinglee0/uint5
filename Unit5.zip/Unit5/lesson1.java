public class lesson1 {
}
class Class1 {
    public int a;
    public int b;
    public static int c;
}
class example1 {

    public static void main(String[] args){
        Class1 one=new Class1();
        Class1 two=new Class1();
        System.out.println(one.a+"  "+one.b+" "+one.c);
        System.out.println(two.a+"  "+two.b+" "+two.c);
        one.c=2;one.a=3;one.b=3;
        System.out.println("one: "+one.a+"  "+one.b+" "+one.c);
        System.out.println("two: "+two.a+"  "+two.b+" "+two.c);
        System.out.println(Class1.c);
    }
}
class Class2 {
    public int a;
    public double b;
    public static int c;
    boolean b1;
    String S1;
    public Class1 one;
    public Class2(){
        double a=1;
        int b=3;
    }
    public Class2(int c){
        a=1;
        b=3;
    }
    public Class2(int d,int e){
        a=1;
        b=3;
        c=d+e;
    }
}
class example2 {

    public static void main(String[] args){
        Class2 one=new Class2();
        Class2 two=new Class2(5);
        Class2 three=new Class2(5,7);
        System.out.println(one.a+"  "+one.b+" "+one.c);
        System.out.println(two.a+"  "+two.b+" "+two.c);
        System.out.println(three.a+"  "+three.b+" "+three.c);
        one.a=3;one.b=3;one.c=2;
        System.out.println("one: "+one.a+"  "+one.b+" "+one.c);
        System.out.println("two: "+two.a+"  "+two.b+" "+two.c);
        Class2.c=10;
        System.out.println(Class2.c);
        System.out.println("two: "+two.a+"  "+two.b+" "+two.c);
        System.out.println("two: "+two.one+" "+two.b1+" "+two.S1);

        two.one=new Class1();
        System.out.println("two: "+two.one.a+" "+two.one.b);
    }
}
/**
 *
 *
 *
 *
 */


